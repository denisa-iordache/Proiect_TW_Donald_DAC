const { DataTypes } = require("sequelize/dist");
const sequelize = require("../sequelize");
const Proiect = require("./proiect");
const Student = require("./student");

const Bug = sequelize.define(
    "Bug",
    {
        id_bug: {
            type: DataTypes.INTEGER,
            primaryKey: true,
            autoIncrement: true,
            allowNull: false
        },
        id_proiect: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        id_tst: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        severitate: {
            type: DataTypes.STRING,
            allowNull: false
        },
        prioritate_de_rezolvare: {
            type: DataTypes.STRING,
            allowNull: false
        },
        descriere: {
            type: DataTypes.STRING,
            allowNull: false
        },
        link_commit_bug: {
            type: DataTypes.STRING,
            allowNull: false,
            // isUrl: true //nu cred ca mai e nevoie ca oricum se verifica asta si in validate
            // validare repo de git (verifica sa fie fix link de repo)
            validate: {
                is: /^(([A-Za-z0-9]+@|http(|s)\:\/\/)|(http(|s)\:\/\/[A-Za-z0-9]+@))([A-Za-z0-9.]+(:\d+)?)(?::|\/)([\d\/\w.-]+?)(\.git){1}$/i
            }
        },
        id_membru: {
            type: DataTypes.INTEGER,
            allowNull: false,
            unique: true //TODO nu poate avea mai multe buguri de rezolvat dintr-un anumit proiect sau in total, 
            //din toate proiecte din care face parte?
        },
        status_rezolvare: {
            type: DataTypes.STRING,
            allowNull: false
        },
        link_commit_rezolvare: {
            type: DataTypes.STRING,
            allowNull: false,
            //validare repo git
            validate: {
                is: /^(([A-Za-z0-9]+@|http(|s)\:\/\/)|(http(|s)\:\/\/[A-Za-z0-9]+@))([A-Za-z0-9.]+(:\d+)?)(?::|\/)([\d\/\w.-]+?)(\.git){1}$/i
            }

        }
    }, { tableName: "Buguri" }
);

// definire foreign keys (not sure)
Bug.belongsTo(Student, { foreignKey: id_tst, id_student });
Bug.belongsTo(Student, { foreignKey: id_membru, id_student });
Bug.belongsTo(Proiect, { foreignKey: id_proiect, id_proiect });

module.exports = Bug;