const { DataTypes } = require("sequelize/dist");
const sequelize = require("../sequelize");
const Proiect = require("./proiect");
const Student = require("./student");

const Tester_proiect = sequelize.define(
    "Tester_proiect",
    {
        id_proiect: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        id_student_tst: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    }, { tableName: "Testeri_proiecte" }
);

// foreign keys 
Tester_proiect.belongsTo(Student, { foreignKey: id_student_tst, id_student });
Tester_proiect.belongsTo(Proiect, { foreignKey: id_proiect, id_proiect });

module.exports = Tester_proiect;