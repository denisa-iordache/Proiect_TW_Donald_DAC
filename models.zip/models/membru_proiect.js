const { DataTypes } = require("sequelize/dist");
const sequelize = require("../sequelize");
const Proiect = require("./proiect");
const Student = require("./student");

const Membru_proiect = sequelize.define(
    "Membru_proiect",
    {
        id_proiect: {
            type: DataTypes.INTEGER,
            allowNull: false
        },
        id_student_mp: {
            type: DataTypes.INTEGER,
            allowNull: false
        }
    }, { tableName: "Membri_proiecte" }
);

// foreign keys ?
Membru_proiect.belongsTo(Student, { foreignKey: id_student_mp, id_student });
Membru_proiect.belongsTo(Proiect, { foreignKey: id_proiect, id_proiect });

module.exports = Membru_proiect;